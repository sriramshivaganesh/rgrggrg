import React, { useState } from 'react';
import BookForm from './BookForm';
import BookTable from './BookTable';
import 'bootstrap/dist/css/bootstrap.min.css'; 


const App = () => {
  const [books, setBooks] = useState([]);

  const addBook = (book) => {
    setBooks([...books, book]);
  };

  return (
    <div>
      <div >
        <div>
          <BookForm addBook={addBook} />
        </div>
        <div>
          <BookTable books={books} />
        </div>
      </div>
    </div>
  );
};

export default App;