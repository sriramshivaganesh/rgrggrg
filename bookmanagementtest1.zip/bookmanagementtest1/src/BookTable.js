import React from 'react';
const BookTable = ({ books }) => {
  return (
    <div className="container mt-4">
      <table className="table table-bordered">
        <thead className="thead-dark">
          <tr>
            <th>Name of the Book</th>
            <th>Author</th>
            <th>Publication</th>
            <th>Price</th>
          </tr>
        </thead>
        <tbody>
          {books.map((book, index) => (
            <tr key={index}>
              <td>{book.title}</td>
              <td>{book.author}</td>
              <td>{book.publication}</td>
              <td>{book.price}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default BookTable;